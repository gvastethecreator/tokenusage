# TokenUsage · Reports Engineering Pack

**Versión documental 2.0 · 12 de septiembre de 2026 · Estado: propuesta técnica, no implementación**

Este paquete convierte el RFC de Reports Workbench en un programa de implementación verificable. Está escrito para el mantenedor y para un agente que trabaje sobre el repositorio: explica qué cambiar, qué preservar, cómo probarlo y qué evidencia impide dar una fase por terminada. La documentación está en español; los nombres de interfaz de la aplicación permanecen en inglés.

**Base revalidada:** `gvastethecreator/tokenusage@df50c367b083e5624bf09213eddc7013d8299aa4`. La rama `main` consultada sigue en ese commit. No se creó ninguna issue, rama, commit ni PR. No se ejecutó TokenUsage ni se accedió a los datos de una computadora personal.

## Empezar aquí

| Documento | Para qué sirve |
|---|---|
| [Plan maestro](docs/00-MASTER-PLAN.md) | Orden de ejecución, dependencias, cortes verticales, riesgos y decisiones. |
| [Base técnica y correcciones](docs/01-BASELINE-AND-FINDINGS.md) | Evidencia del código existente y precisión del diagnóstico anterior. |
| [P0 · Exactitud](docs/phases/P0-CORRECTNESS.md) | Corregir la comparación Rates, fijar semántica y proteger contratos existentes. |
| [P1 · Model Explorer](docs/phases/P1-MODEL-EXPLORER.md) | Consultas, filtros, tabla, detalle, evidencia y experiencia nativa. |
| [P2 · Detalle verificable](docs/phases/P2-VERIFIABLE-DETAIL.md) | Identidad, granularidad, reconciliación, capacidades y actividad temporal. |
| [P3 · Sesiones y proyectos](docs/phases/P3-SESSIONS-PROJECTS.md) | Consentimiento, atribución, pseudónimos, jerarquías y borrado. |
| [P4 · Explicaciones y exportación](docs/phases/P4-INSIGHTS-EXPORTS.md) | Insights deterministas, distribuciones, escenarios y exportaciones reproducibles. |
| [Arquitectura y contratos](docs/architecture/02-CONTRACTS-AND-DATA-FLOW.md) | Fronteras de responsabilidad, revisión coherente, DTO y planificación. |
| [Diccionario de métricas](docs/architecture/03-METRIC-SEMANTICS.md) | Fórmulas, unidades, elegibilidad, denominadores y exclusiones. |
| [Calidad y pruebas](docs/quality/04-QUALITY-GATES.md) | Pruebas por riesgo, casos adversariales y evidencias exigidas. |
| [Especificación de experiencia](docs/quality/05-UX-AND-ACCESSIBILITY.md) | Estados, teclado, diseño, accesibilidad y revisión visual. |
| [Rendimiento](docs/quality/06-PERFORMANCE-PROTOCOL.md) | Fixtures de carga, medición, cancelación y objetivos provisionales. |
| [Privacidad y seguridad](docs/operations/07-PRIVACY-AND-THREATS.md) | Datos permitidos, amenazas, permisos, exports y límites del borrado. |
| [Migración y recuperación](docs/operations/08-MIGRATIONS-AND-RECOVERY.md) | Evolución aditiva, copias coherentes, fallos y rollback seguro. |
| [Entrega a agentes y backlog](docs/operations/09-AGENT-HANDOFF.md) | Tareas acotadas, plantilla de issue/PR y comandos comprobados. |
| [Fuentes](docs/references/10-SOURCES.md) | Permalinks, alcance de inspección y referencias oficiales. |

`index.html` contiene una edición navegable de estos 17 documentos (incluido este índice), sin CDN ni servidor. No es otra interfaz de TokenUsage; es el lector de esta documentación. `archive/` conserva el RFC inicial como antecedente, no como especificación vigente cuando exista una corrección expresa.

## Qué cambió respecto del RFC inicial

La fórmula de `SplitKnownCost` tiene la limitación algebraica descrita, pero el llamador de UI inspeccionado la usa en **Rates**, que revaloriza una misma cohorte a dos fechas de catálogo. Por eso P0 no parte de afirmar que toda comparación histórica está mal. La solución prioritaria es definir una población idéntica y valorizable en ambas fechas, distinguir el cambio de precio de los cambios de cobertura y tratar volumen/mezcla como dimensiones no aplicables a ese experimento. La descomposición histórica de tres factores se reserva para P4 y exige datos adicionales. Véanse [base](docs/01-BASELINE-AND-FINDINGS.md) y [P0](docs/phases/P0-CORRECTNESS.md).

## Qué hay de ejecutable

`schemas/` y `fixtures/` son contratos y casos **de diseño**, no un nuevo contrato publicado de la CLI. `tools/validate_pack.py` comprueba estructura del paquete, contratos de ejemplo y propiedades matemáticas seleccionadas. Esas comprobaciones no sustituyen tests C#, integración de fuentes ni pruebas WinUI. El informe generado en `validation/` enumera exactamente lo ejecutado y lo no ejecutado. El validador requiere Python 3.10 o posterior; la comprobación de esquemas utiliza `jsonschema` si está instalado. Si falta esa dependencia, devuelve estado parcial y código de salida 2, sin declarar esa validación aprobada.

```powershell
# Sólo para validar este paquete documental; no toca el repositorio ni tus datos.
python .\tools\validate_pack.py
```

## Convenciones

**VERIFICADO** significa leído en el código o documentación citados, no ejecutado. **PROPUESTO** significa una decisión recomendada de este paquete. **GATE** es un requisito pendiente para habilitar o publicar. **OBJETIVO PROVISIONAL** identifica un presupuesto de calidad que debe calibrarse y aprobarse con una medición en Windows.

Los IDs `REQ-*`, `TEST-*`, `TASK-*` y `GATE-*` enlazan obligaciones, pruebas y tareas. No son números de issues existentes. Ninguna métrica pendiente, escenario sintético o comparación algebraica debe presentarse como uso real del usuario.
