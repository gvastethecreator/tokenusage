# TokenUsage — propuesta de evolución de informes

Abrí `tokenusage-reports-lab.html` en un navegador. Es autónomo y emplea sólo datos sintéticos: no lee tu PC, no se conecta a cuentas y no modifica TokenUsage. La interfaz de ejemplo está en inglés, como el producto actual.

`TOKENUSAGE_REPORTS_RFC.md` contiene el análisis, la propuesta de arquitectura, las entregas y sus criterios de aceptación. No representa código ya implementado ni un PR publicado.

`verify_cost_split.py` se ejecuta con Python 3 sin dependencias externas. Comprueba fórmulas y casos sintéticos; no ejecuta el código C# de TokenUsage. Los resultados están en `cost-split-checks.json`.

`browser-check.py` contiene las pruebas de humo del HTML y requiere Playwright y un navegador Chromium. Admite `CHROMIUM_EXECUTABLE` para seleccionar el ejecutable. Las comprobaciones realizadas se registraron en `validation.json`.

Revisión estática de TokenUsage: commit df50c367b083e5624bf09213eddc7013d8299aa4. No se ejecutó la aplicación Windows ni se modificó el repositorio.
