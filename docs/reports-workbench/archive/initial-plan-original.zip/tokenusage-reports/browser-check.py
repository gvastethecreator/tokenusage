"""Smoke test for the standalone design prototype, not the Windows app."""
from pathlib import Path
import json
import os
import shutil
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parent
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_EXECUTABLE') or shutil.which('chromium') or shutil.which('google-chrome'),args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':1060},device_scale_factor=1)
    errors=[]
    page.on('pageerror',lambda error: errors.append(str(error)))
    page.set_content((root/'tokenusage-reports-lab.html').read_text(), wait_until='load')
    assert page.locator('#rows tr').count()==5
    assert page.locator('#summary .value').nth(0).inner_text()=='2.84M'
    assert page.locator('#summary .value').nth(1).inner_text()=='$18.68'
    assert page.locator('#summary .value').nth(3).inner_text()=='108'
    page.screenshot(path=str(root/'preview-desktop.png'),full_page=True)
    page.select_option('#tool','Cursor')
    assert page.locator('#rows tr').count()==1
    assert page.locator('#summary .value').nth(1).inner_text()=='—'
    assert page.locator('#summary .value').nth(3).inner_text()=='—'
    assert 'Not available for this grain' in page.locator('#detail').inner_text()
    page.click('#tab-evidence')
    assert page.locator('#priced-value').inner_text()=='0.0% with cost attribution'
    assert page.locator('#exact-value').inner_text()=='0.0% exact-time eligible'
    page.click('#tab-architecture')
    page.click('[data-stage="2"]')
    assert 'ReportQuery' in page.locator('#arch-detail').inner_text()
    page.click('#tab-roadmap')
    assert page.locator('.phase').count()==5
    page.click('#tab-models')
    page.select_option('#tool','all')
    page.fill('#search','DOES NOT EXIST')
    assert page.locator('#rows tr').count()==0
    assert page.locator('#empty').is_visible()
    page.fill('#search','')
    page.select_option('#sort','value')
    assert page.locator('#rows tr').first.locator('.model-button').inner_text()=='Model A'
    with page.expect_download() as download_info:
        page.click('#export')
    download=download_info.value
    demo=json.loads(Path(download.path()).read_text())
    assert demo['synthetic'] is True and demo['totals']['tokens']==2838000
    page.set_viewport_size({'width':390,'height':844})
    assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
    page.screenshot(path=str(root/'preview-mobile.png'),full_page=True)
    assert not errors, errors
    browser.close()
result={'prototype_only':True,'javascript_syntax':'passed','browser':'headless Chromium',
        'checks':['filtering','empty state','known totals','unknown cost remains unknown','request eligibility','evidence calculations','architecture navigation','delivery phases','synthetic JSON export','mobile page overflow','no page errors'],
        'windows_app_executed':False,'github_modified':False}
(root/'validation.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
