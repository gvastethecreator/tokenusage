"""Synthetic algebra checks; does not execute TokenUsage or its C# tests."""
from decimal import Decimal as D
import json


def inspected_formula(a: D, b: D, qa: D, qb: D) -> tuple[D, D, D]:
    if qa <= 0 or qb <= 0:
        raise ValueError("This demonstration requires positive comparable volumes")
    volume = a * (qb / qa - 1)
    rate = (b / qb - a / qa) * qb
    return volume, b - a - volume - rate, rate


def decomposition(q0: D, q1: D, s0: list[D], s1: list[D], r0: list[D], r1: list[D]) -> tuple[D, D, D, D]:
    if not (len(s0) == len(s1) == len(r0) == len(r1)):
        raise ValueError("Cell counts must match")
    if q0 <= 0 or q1 <= 0 or sum(s0) != 1 or sum(s1) != 1:
        raise ValueError("Positive volumes and complete shares are required")
    rate0 = sum(s*r for s, r in zip(s0, r0))
    c0 = q0 * rate0
    c1 = q1 * sum(s*r for s, r in zip(s1, r1))
    volume = (q1 - q0) * rate0
    mix = q1 * sum((b-a)*r for a, b, r in zip(s0, s1, r0))
    price = q1 * sum(s*(b-a) for s, a, b in zip(s1, r0, r1))
    assert c1 - c0 == volume + mix + price
    return volume, mix, price, c1 - c0


def main() -> None:
    old = inspected_formula(D(1), D(2), D(100), D(100))
    assert old == (D(0), D(0), D(1))
    # Switch from cell A to B with unchanged tariff schedules: mix, not price.
    mix = decomposition(D(100), D(100), [D(1), D(0)], [D(0), D(1)],
                        [D('.01'), D('.02')], [D('.01'), D('.02')])
    assert mix == (D(0), D(1), D(0), D(1))
    volume = decomposition(D(100), D(200), [D(1)], [D(1)], [D('.01')], [D('.01')])
    assert volume == (D(1), D(0), D(0), D(1))
    rate = decomposition(D(100), D(100), [D(1)], [D(1)], [D('.01')], [D('.02')])
    assert rate == (D(0), D(0), D(1), D(1))
    combined = decomposition(D(100), D(140), [D('.8'), D('.2')], [D('.4'), D('.6')],
                             [D('.01'), D('.02')], [D('.012'), D('.021')])
    print(json.dumps({"synthetic_only": True, "inspected_formula": list(map(str, old)),
                      "correct_mix_only": list(map(str, mix)), "volume_only": list(map(str, volume)),
                      "rate_only": list(map(str, rate)), "combined": list(map(str, combined)),
                      "checks": "passed", "windows_app_executed": False}, indent=2))


if __name__ == '__main__':
    main()
